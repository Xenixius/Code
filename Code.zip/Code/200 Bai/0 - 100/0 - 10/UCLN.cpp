#include <bits/stdc++.h>
using namespace std;

int main(){
  ios_base::sync_with_stdio(0);cin.tie(0);cout.tie(0);
  freopen("UCLN.INP", "r", stdin);
  freopen("UCLN.OUT", "w", stdout);
  int n, m;
  cin >> n >> m;
  cout <<  __gcd(n, m);
  return 0;
}
