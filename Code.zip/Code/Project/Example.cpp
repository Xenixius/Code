#include <bits/stdc++.h>
#define int long long
#define FOR(i, a, b, d) for (int i = (a); i < (b); i += (d))
#define File(name) freopen(name".INP", "r", stdin); freopen(name".OUT", "w", stdout);

using namespace std;

main() {
    ios_base::sync_with_stdio(0); cin.tie(0); cout.tie(0);
    File("INPFILE"); // Change INPFILE to the name of your program

    // result=kq, right=r, left=l, arr=a, endl='\n', count=d
    // No caps except for function names (single capital letter)
    // Omit {} when possible, use shortest names (e.g. maxheight=mh)
    // for(int i=0;i<n;i++)cin>>a[i] = for(auto&i:a)cin>>i;
    // for(int i=0;i<n;i++)cout<<a[i]<<" "; = for(auto i:a)cout<<i<<" ";
}